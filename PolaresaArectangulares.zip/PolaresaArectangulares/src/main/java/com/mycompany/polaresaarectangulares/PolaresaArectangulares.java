
package com.mycompany.polaresaarectangulares;
import java.util.Scanner;
/**
 * @author Estudiante: Valentina Zambrano Sánchez
 */
public class PolaresaArectangulares {

    public static void main(String[] args) 
    {
    Scanner scanner = new Scanner(System.in);
    boolean salir = false;
    
    while (!salir) {
        System.out.println(" Menu");
        System.out.println(" 1.Convertir coordenadas de su origen polar al rectangular");
        System.out.println(" 2.Convertir coordenadas de su origen rectangular al polar");
        System.out.println(" 3.Salir");
        System.out.println("Digite la opción que desee: ");
        int opcion = scanner.nextInt();
        
        switch (opcion) {
            case 1:
                polarArectangular(scanner);
                break;
            
            case 2:
                rectangularApolar(scanner);
                break;
            
            case 3:
                salir = true;
                break;
            default:
                System.out.println(" Opcion no encontrada, digite de nuevo.");
        }        
    } 
    }
    
    private static void polarArectangular (Scanner scanner) 
    {
        System.out.println(" Digite el angulo correspondiente (en grados)");
        double angulo = scanner.nextDouble();
        System.out.println(" Digite el radio correspondiente (en grados)");
        double radio = scanner.nextDouble();
        
        //grados a radianes
        double anguloEnradianes = Math.toRadians(angulo);
        
        //calcular coordenadas rectangulares
        double X = radio * Math.cos(anguloEnradianes);
        double Y = radio * Math.sin(anguloEnradianes);
        
    }
    
     private static void rectangularApolar (Scanner scanner) 
    {
        System.out.println(" Digite la coordenada X: ");
        double X = scanner.nextDouble();
        System.out.println(" Digite la coordenada y: ");
        double Y = scanner.nextDouble();
    }
    
}
